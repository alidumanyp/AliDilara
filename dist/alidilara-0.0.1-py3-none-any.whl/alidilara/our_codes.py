def multiplyNumber(x):
    return 2*x